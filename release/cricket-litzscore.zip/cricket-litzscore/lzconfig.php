<?php

define('LZ_url', 'https://api.litzscore.com/rest/v2/');
define('LZ_device_id', '12345');

$lzconfig = array(
	'refresh_rate' => 5000,
);


?>